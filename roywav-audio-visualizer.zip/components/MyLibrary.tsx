import React from 'react';
import { ShareIcon, GlobeIcon, LockIcon } from './Icons';

export interface SavedTrack {
  name: string;
  isPublic: boolean;
}

interface MyLibraryProps {
  tracks: SavedTrack[];
  username: string;
  onShare: (trackName: string) => void;
  onBack: () => void;
  onTogglePrivacy: (trackName: string) => void;
}

export const MyLibrary: React.FC<MyLibraryProps> = ({ tracks, onShare, onBack, onTogglePrivacy }) => {
  return (
    <div className="w-full max-w-2xl flex flex-col items-center space-y-6 pt-8">
        <div className="w-full flex justify-between items-center">
            <h2 className="text-2xl md:text-3xl font-bold text-white">My Library</h2>
            <button onClick={onBack} className="text-sm text-purple-400 hover:text-purple-300 transition-colors">
            &larr; Back to Uploader
            </button>
        </div>
      
      {tracks.length > 0 ? (
        <ul className="space-y-3 w-full">
          {tracks.map((track) => (
            <li key={track.name} className="flex items-center justify-between bg-gray-900/50 p-3 rounded-lg border border-gray-800">
                <div className="flex flex-col">
                    <span className="text-gray-200 font-medium truncate" title={track.name}>{track.name}</span>
                    <span className={`text-xs ${track.isPublic ? 'text-green-400' : 'text-gray-400'}`}>
                        {track.isPublic ? 'Public' : 'Private'}
                    </span>
                </div>
              <div className="flex items-center space-x-2 md:space-x-4">
                <button
                  onClick={() => onShare(track.name)}
                  className="p-2 text-gray-400 hover:text-purple-400 transition-colors"
                  title="Share Track"
                >
                  <ShareIcon />
                </button>
                <button
                  onClick={() => onTogglePrivacy(track.name)}
                  className="p-2 text-gray-400 hover:text-white transition-colors"
                  title={track.isPublic ? 'Make Private' : 'Make Public'}
                >
                    {track.isPublic ? <LockIcon size={20} /> : <GlobeIcon size={20}/>}
                </button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="text-center py-16 px-4 bg-gray-900/50 border border-gray-800 rounded-lg w-full">
          <h3 className="text-xl font-semibold text-white">Your library is empty.</h3>
          <p className="text-gray-400 mt-2">
            Upload a track from the main page and save it to see it here.
          </p>
        </div>
      )}
    </div>
  );
};