import React from 'react';

export interface PublicTrack {
  name: string;
  user: string;
}

interface PublicGalleryProps {
  tracks: PublicTrack[];
  onBack: () => void;
}

export const PublicGallery: React.FC<PublicGalleryProps> = ({ tracks, onBack }) => {
  return (
    <div className="w-full max-w-2xl flex flex-col items-center space-y-6 pt-8">
      <div className="w-full flex justify-between items-center">
        <h2 className="text-2xl md:text-3xl font-bold text-white">Public Gallery</h2>
        <button onClick={onBack} className="text-sm text-purple-400 hover:text-purple-300 transition-colors">
          &larr; Back to Uploader
        </button>
      </div>

      {tracks.length > 0 ? (
        <ul className="space-y-3 w-full">
          {tracks.map((track, index) => (
            <li key={`${track.name}-${track.user}-${index}`} className="flex items-center justify-between bg-gray-900/50 p-3 rounded-lg border border-gray-800">
              <div className="flex flex-col overflow-hidden">
                <span className="text-gray-200 font-medium truncate" title={track.name}>{track.name}</span>
                <span className="text-xs text-gray-400">
                  Shared by <span className="font-semibold text-purple-400">{track.user}</span>
                </span>
              </div>
               {/* Note: Playback from gallery is not supported in this frontend-only simulation */}
            </li>
          ))}
        </ul>
      ) : (
        <div className="text-center py-16 px-4 bg-gray-900/50 border border-gray-800 rounded-lg w-full">
            <h3 className="text-xl font-semibold text-white">The gallery is quiet...</h3>
            <p className="text-gray-400 mt-2">
                No public tracks have been shared yet. Be the first!
            </p>
        </div>
      )}
    </div>
  );
};