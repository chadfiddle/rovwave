import React, { useState, useCallback } from 'react';
import { UploadIcon } from './Icons';

interface AudioUploaderProps {
  onFileChange: (file: File) => void;
}

export const AudioUploader: React.FC<AudioUploaderProps> = ({ onFileChange }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (files: FileList | null) => {
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type === 'audio/mpeg' || file.type === 'audio/wav') {
        onFileChange(file);
      } else {
        alert('Please upload a valid MP3 or WAV file.');
      }
    }
  };

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);
  
  const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  }, [onFileChange]);

  const baseClasses = "flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ease-in-out";
  const inactiveClasses = "border-gray-600 bg-gray-900/50 hover:bg-gray-800/60";
  const activeClasses = "border-purple-500 bg-purple-900/20";

  return (
    <label
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={`${baseClasses} ${isDragging ? activeClasses : inactiveClasses}`}
    >
      <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center">
        <UploadIcon />
        <p className="mb-2 text-sm text-gray-400">
          <span className="font-semibold text-purple-400">Click to upload</span> or drag and drop
        </p>
        <p className="text-xs text-gray-500">MP3 or WAV files</p>
      </div>
      <input
        type="file"
        className="hidden"
        accept=".mp3,.wav"
        onChange={(e) => handleFileSelect(e.target.files)}
      />
    </label>
  );
};