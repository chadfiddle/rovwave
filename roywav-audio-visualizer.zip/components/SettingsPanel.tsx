import React from 'react';

export interface VisualizerSettings {
  style: 'cosmic' | 'bars';
  colorScheme: 'rainbow' | 'fire' | 'ocean' | 'nebula';
  particleDensity: 'low' | 'medium' | 'high';
  starfieldSpeed: 'off' | 'slow' | 'fast';
  showNebula: boolean;
}

interface SettingsPanelProps {
  settings: VisualizerSettings;
  onSettingsChange: (newSettings: VisualizerSettings) => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSettingsChange }) => {
  const handleSettingChange = <K extends keyof VisualizerSettings>(key: K, value: VisualizerSettings[K]) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  const inputClasses = "w-full p-2 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors";

  const Toggle: React.FC<{
    label: string;
    checked: boolean;
    onChange: (checked: boolean) => void;
  }> = ({ label, checked, onChange }) => (
    <label className="flex items-center justify-between cursor-pointer">
      <span className="text-sm font-medium text-gray-300">{label}</span>
      <div className="relative">
        <input type="checkbox" className="sr-only" checked={checked} onChange={e => onChange(e.target.checked)} />
        <div className={`block w-10 h-6 rounded-full transition-colors ${checked ? 'bg-purple-600' : 'bg-gray-600'}`}></div>
        <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${checked ? 'transform translate-x-full' : ''}`}></div>
      </div>
    </label>
  );

  return (
    <div className="w-full max-w-md mt-4">
      <h3 className="text-lg font-bold text-white mb-4 text-center">Customize Visuals</h3>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="visualizer-style" className="block text-sm font-medium text-gray-300 mb-1">
                Style
              </label>
              <select
                id="visualizer-style"
                value={settings.style}
                onChange={(e) => handleSettingChange('style', e.target.value as VisualizerSettings['style'])}
                className={inputClasses}
              >
                <option value="cosmic">Cosmic Drift</option>
                <option value="bars">Bars</option>
              </select>
            </div>
            <div>
              <label htmlFor="color-scheme" className="block text-sm font-medium text-gray-300 mb-1">
                Color Scheme
              </label>
              <select
                id="color-scheme"
                value={settings.colorScheme}
                onChange={(e) => handleSettingChange('colorScheme', e.target.value as VisualizerSettings['colorScheme'])}
                className={inputClasses}
              >
                <option value="rainbow">Rainbow</option>
                <option value="nebula">Nebula</option>
                <option value="fire">Fire</option>
                <option value="ocean">Ocean</option>
              </select>
            </div>
        </div>
        
        {settings.style === 'cosmic' && (
          <div className="p-4 bg-black/20 border border-gray-700/50 rounded-lg space-y-4">
            <h4 className="text-sm font-bold text-center text-purple-300 uppercase tracking-wider">Cosmic Settings</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <label htmlFor="particle-density" className="block text-sm font-medium text-gray-300 mb-1">
                        Particle Density
                    </label>
                    <select
                        id="particle-density"
                        value={settings.particleDensity}
                        onChange={(e) => handleSettingChange('particleDensity', e.target.value as VisualizerSettings['particleDensity'])}
                        className={inputClasses}
                    >
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="starfield-speed" className="block text-sm font-medium text-gray-300 mb-1">
                        Starfield Speed
                    </label>
                    <select
                        id="starfield-speed"
                        value={settings.starfieldSpeed}
                        onChange={(e) => handleSettingChange('starfieldSpeed', e.target.value as VisualizerSettings['starfieldSpeed'])}
                        className={inputClasses}
                    >
                        <option value="off">Off</option>
                        <option value="slow">Slow</option>
                        <option value="fast">Fast</option>
                    </select>
                </div>
            </div>
             <div className="pt-2">
                 <Toggle label="Show Nebula" checked={settings.showNebula} onChange={v => handleSettingChange('showNebula', v)} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
