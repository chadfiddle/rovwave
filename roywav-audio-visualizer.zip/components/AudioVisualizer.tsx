import React, { useRef, useEffect } from 'react';
import type { VisualizerSettings } from './SettingsPanel';

interface AudioVisualizerProps {
  analyserNode: AnalyserNode | null;
  isPlaying: boolean;
  settings: VisualizerSettings;
}

const getColor = (value: number, index: number, bufferLength: number, scheme: VisualizerSettings['colorScheme']): string => {
    const percent = value / 255;
    const iPercent = index / bufferLength;

    switch(scheme) {
        case 'fire': {
            const red = 200 + Math.floor(percent * 55);
            const green = Math.floor(percent * 150);
            const blue = 20;
            return `rgba(${red}, ${green}, ${blue}, ${0.5 + percent * 0.5})`;
        }
        case 'ocean': {
            const r = 20;
            const g = Math.floor(percent * 100);
            const b = 180 + Math.floor(percent * 75);
            return `rgba(${r}, ${g}, ${b}, ${0.5 + percent * 0.5})`;
        }
        case 'nebula': {
            const hue = 260 + (iPercent * 100);
            const saturation = 100;
            const lightness = 60 + (percent * 15);
            return `hsla(${hue}, ${saturation}%, ${lightness}%, ${0.5 + percent * 0.5})`;
        }
        case 'rainbow':
        default: {
            const hue = iPercent * 360;
            const saturation = 100;
            const lightness = 50 + (percent * 25);
            return `hsla(${hue}, ${saturation}%, ${lightness}%, ${0.5 + percent * 0.5})`;
        }
    }
}

class Particle {
    x: number; y: number; size: number; speedX: number; speedY: number; color: string;
    constructor(x: number, y: number, size: number, color: string) {
        this.x = x; this.y = y; this.size = size; this.color = color;
        this.speedX = Math.random() * 2 - 1; this.speedY = Math.random() * 2 - 1;
    }
    update() { this.x += this.speedX; this.y += this.speedY; if (this.size > 0.2) this.size -= 0.05; }
    draw(ctx: CanvasRenderingContext2D) {
        ctx.fillStyle = this.color; ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill();
    }
}

interface Star { x: number; y: number; z: number; }

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ analyserNode, isPlaying, settings }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameId = useRef<number>(0);
  const particlesRef = useRef<Particle[]>([]);
  const starsRef = useRef<Star[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !analyserNode) return;
    
    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;

    const resizeCanvas = () => {
        const parent = canvas.parentElement;
        if (!parent) return;
        const { width, height } = parent.getBoundingClientRect();
        canvas.width = width;
        canvas.height = height;
        // Re-initialize stars on resize
        starsRef.current = [];
        for (let i = 0; i < 500; i++) {
            starsRef.current.push({
                x: Math.random() * canvas.width - canvas.width / 2,
                y: Math.random() * canvas.height - canvas.height / 2,
                z: Math.random() * canvas.width
            });
        }
    };
    
    const observer = new ResizeObserver(resizeCanvas);
    if(canvas.parentElement) observer.observe(canvas.parentElement);
    resizeCanvas();
    
    analyserNode.fftSize = 256;
    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    
    const particleThresholds = { low: 0.6, medium: 0.45, high: 0.3 };
    const maxParticles = { low: 50, medium: 100, high: 200 };

    const drawCosmic = () => {
        const WIDTH = canvas.width;
        const HEIGHT = canvas.height;
        const centerX = WIDTH / 2;
        const centerY = HEIGHT / 2;

        const bassAvg = (dataArray[1] + dataArray[2] + dataArray[3]) / 3 / 255;
        const midAvg = dataArray.slice(10, 70).reduce((a, b) => a + b, 0) / 60 / 255;
        
        // --- Starfield ---
        const starSpeed = settings.starfieldSpeed === 'fast' ? 0.4 : settings.starfieldSpeed === 'slow' ? 0.15 : 0;
        if (starSpeed > 0) {
            canvasCtx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            starsRef.current.forEach(star => {
                star.z -= starSpeed;
                if (star.z <= 0) {
                    star.x = Math.random() * WIDTH - centerX;
                    star.y = Math.random() * HEIGHT - centerY;
                    star.z = WIDTH;
                }
                const k = 128 / star.z;
                const px = star.x * k + centerX;
                const py = star.y * k + centerY;
                const size = (1 - star.z / WIDTH) * 2;
                if (px > 0 && px < WIDTH && py > 0 && py < HEIGHT) {
                    canvasCtx.beginPath();
                    canvasCtx.arc(px, py, size, 0, Math.PI * 2);
                    canvasCtx.fill();
                }
            });
        }

        // --- Nebula ---
        if(settings.showNebula && bassAvg > 0.1) {
            const radius = bassAvg * Math.min(WIDTH, HEIGHT) * 0.4;
            const gradient = canvasCtx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
            const baseColor = getColor(180, 1, 2, settings.colorScheme);
            const colorPart = baseColor.substring(0, baseColor.lastIndexOf(','));
            gradient.addColorStop(0, `${colorPart}, ${bassAvg * 0.3})`);
            gradient.addColorStop(1, `${colorPart}, 0)`);
            canvasCtx.fillStyle = gradient;
            canvasCtx.fillRect(0, 0, WIDTH, HEIGHT);
        }
        
        // --- Particles ---
        particlesRef.current.forEach((p, i) => { p.update(); p.draw(canvasCtx); if (p.size <= 0.2) particlesRef.current.splice(i, 1); });
        if (midAvg > particleThresholds[settings.particleDensity] && particlesRef.current.length < maxParticles[settings.particleDensity]) {
            for (let i = 0; i < 2; i++) {
                const x = Math.random() * WIDTH; const y = Math.random() * HEIGHT; const size = Math.random() * 2 + 1;
                const color = getColor(dataArray[Math.floor(Math.random()*bufferLength)], Math.floor(Math.random()*bufferLength), bufferLength, settings.colorScheme);
                particlesRef.current.push(new Particle(x, y, size, color));
            }
        }
        
        // --- Energy Beams ---
        const lines = 8;
        canvasCtx.save();
        canvasCtx.translate(centerX, centerY);
        canvasCtx.rotate(animationFrameId.current * 0.0003);

        for (let i = 0; i < lines; i++) {
            canvasCtx.rotate((Math.PI * 2) / lines);
            const value = dataArray[Math.floor(i * (bufferLength / lines))];
            const percent = value / 255;
            if (percent < 0.1) continue;

            const length = 50 + percent * (Math.min(WIDTH, HEIGHT) * 0.35);
            const intensity = 0.5 + midAvg * 0.5;
            
            const gradient = canvasCtx.createLinearGradient(0, 0, 0, length);
            const beamColor = getColor(value, i, lines, settings.colorScheme);
            const beamColorPart = beamColor.substring(0, beamColor.lastIndexOf(','));

            gradient.addColorStop(0, 'rgba(0,0,0,0)');
            gradient.addColorStop(0.5, `${beamColorPart}, ${intensity})`);
            gradient.addColorStop(1, 'rgba(0,0,0,0)');

            canvasCtx.beginPath();
            canvasCtx.strokeStyle = gradient;
            canvasCtx.lineWidth = 1 + percent * 4;
            canvasCtx.moveTo(0, 0);
            canvasCtx.lineTo(0, length);
            canvasCtx.stroke();
        }
        canvasCtx.restore();
    };

    const drawBars = () => {
        const barWidth = canvas.width / bufferLength * 1.5;
        let x = 0;
        for (let i = 0; i < bufferLength; i++) {
            const value = dataArray[i];
            const barHeight = (value / 255) * canvas.height;
            canvasCtx.fillStyle = getColor(value, i, bufferLength, settings.colorScheme);
            canvasCtx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
            x += barWidth;
        }
    };

    const draw = () => {
      animationFrameId.current = requestAnimationFrame(draw);
      if (!analyserNode) return;
      analyserNode.getByteFrequencyData(dataArray);

      canvasCtx.fillStyle = 'rgba(10, 10, 15, 0.15)';
      canvasCtx.fillRect(0, 0, canvas.width, canvas.height);

      if (!isPlaying) {
        if(particlesRef.current.length > 0) particlesRef.current = [];
        canvasCtx.fillStyle = 'rgb(10, 10, 15)';
        canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
        return;
      }
      
      if(settings.style === 'cosmic') {
        drawCosmic();
      } else if (settings.style === 'bars') {
        drawBars();
      }
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId.current);
      if(canvas.parentElement) observer.unobserve(canvas.parentElement);
    };
  }, [analyserNode, isPlaying, settings]);

  return <canvas ref={canvasRef} className="w-full h-full block" />;
};