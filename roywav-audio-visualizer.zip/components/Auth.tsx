import React, { useState } from 'react';
import { RoyWavIcon } from './Icons';

interface AuthProps {
  onLogin: (username: string) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onLogin(username.trim());
    }
  };

  return (
    <div className="w-full max-w-sm mx-auto flex flex-col items-center justify-center min-h-screen p-4">
      <header className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight flex items-center gap-3 justify-center group">
          <RoyWavIcon />
          ROYWAV
        </h1>
        <p className="text-lg text-gray-400 mt-2">Sign in to save & share.</p>
      </header>
      <form onSubmit={handleSubmit} className="w-full space-y-6">
        <div>
          <label htmlFor="username" className="sr-only">
            Choose a Username
          </label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Choose a Username"
            className="w-full p-3 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 transition-colors text-white placeholder-gray-400 text-center"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 px-4 rounded-md transition-all duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-75 disabled:bg-gray-600 disabled:scale-100"
          disabled={!username.trim()}
        >
          Enter ROYWAV
        </button>
      </form>
    </div>
  );
};