import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Auth } from './components/Auth';
import { MyLibrary, SavedTrack } from './components/MyLibrary';
import { PublicGallery, PublicTrack } from './components/PublicGallery';
import { AudioUploader } from './components/AudioUploader';
import { AudioVisualizer } from './components/AudioVisualizer';
import { SettingsPanel, VisualizerSettings } from './components/SettingsPanel';
import { PlayIcon, PauseIcon, RoyWavIcon, ExitFullScreenIcon, LogoutIcon, LibraryIcon, GlobeIcon, LockIcon } from './components/Icons';

type View = 'app' | 'library' | 'gallery';
type SharedTrackInfo = { user: string, track: string } | null;


export default function App(): React.ReactNode {
  // Auth & Data State
  const [user, setUser] = useState<string | null>(null);
  const [savedTracks, setSavedTracks] = useState<SavedTrack[]>([]);
  const [publicTracks, setPublicTracks] = useState<PublicTrack[]>([]);
  
  // UI State
  const [view, setView] = useState<View>('app');
  const [sharedTrackInfo, setSharedTrackInfo] = useState<SharedTrackInfo>(null);
  const [showNotification, setShowNotification] = useState<string | null>(null);
  const [isPublic, setIsPublic] = useState(true);

  // Player State
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isFullScreen, setIsFullScreen] = useState<boolean>(false);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [visualizerSettings, setVisualizerSettings] = useState<VisualizerSettings>({
    style: 'cosmic',
    colorScheme: 'rainbow',
    particleDensity: 'medium',
    starfieldSpeed: 'slow',
    showNebula: true,
  });

  const audioRef = useRef<HTMLAudioElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  
  // === NOTIFICATION HELPER ===
  const notify = (message: string) => {
    setShowNotification(message);
    setTimeout(() => setShowNotification(null), 3000);
  };

  // === DATA SYNC LOGIC ===
  const syncPublicGallery = (tracks: PublicTrack[]) => {
    localStorage.setItem('roywav_public_gallery', JSON.stringify(tracks));
    setPublicTracks(tracks);
  };

  const syncUserLibrary = (username: string, tracks: SavedTrack[]) => {
    localStorage.setItem(`roywav_uploads_${username}`, JSON.stringify(tracks));
    setSavedTracks(tracks);
  }

  // === AUTH & DATA LOGIC ===
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sharedUser = params.get('shared_by');
    const sharedTrack = params.get('track');
    if (sharedUser && sharedTrack) {
        setSharedTrackInfo({ user: sharedUser, track: sharedTrack });
    }

    const loggedInUser = localStorage.getItem('roywav_user');
    if (loggedInUser) {
        handleLogin(loggedInUser);
    }
    
    // Load public gallery for all users
    const gallery = JSON.parse(localStorage.getItem('roywav_public_gallery') || '[]');
    setPublicTracks(gallery);

  }, []);

  const handleLogin = (username: string) => {
    localStorage.setItem('roywav_user', username);
    setUser(username);
    const userTracks = JSON.parse(localStorage.getItem(`roywav_uploads_${username}`) || '[]');
    setSavedTracks(userTracks);
  };
  
  const handleLogout = () => {
    localStorage.removeItem('roywav_user');
    setUser(null);
    setAudioFile(null);
    setAudioUrl(null);
    setIsPlaying(false);
    setIsFullScreen(false);
    setView('app');
  };
  
  const handleSaveTrack = () => {
    if (!audioFile || !user) return;
    
    if (savedTracks.some(t => t.name === audioFile.name)) {
        notify("Track is already in your library.");
        return;
    }

    const newTrack: SavedTrack = { name: audioFile.name, isPublic: isPublic };
    const updatedTracks = [...savedTracks, newTrack];
    syncUserLibrary(user, updatedTracks);

    if (isPublic) {
        const galleryTrack: PublicTrack = { name: audioFile.name, user: user };
        const updatedGallery = [...publicTracks, galleryTrack];
        syncPublicGallery(updatedGallery);
    }
    notify(`Track saved as ${isPublic ? 'Public' : 'Private'}!`);
  };

  const handleToggleTrackPrivacy = (trackName: string) => {
      if(!user) return;
      
      const updatedTracks = savedTracks.map(t => t.name === trackName ? {...t, isPublic: !t.isPublic} : t);
      syncUserLibrary(user, updatedTracks);

      const track = updatedTracks.find(t => t.name === trackName);
      let updatedGallery = [...publicTracks];

      if (track?.isPublic) {
          // Add to public gallery if not already there
          if (!updatedGallery.some(p => p.name === trackName && p.user === user)) {
              updatedGallery.push({ name: track.name, user: user });
          }
      } else {
          // Remove from public gallery
          updatedGallery = updatedGallery.filter(p => !(p.name === trackName && p.user === user));
      }
      syncPublicGallery(updatedGallery);
      notify(`'${trackName}' is now ${track?.isPublic ? 'Public' : 'Private'}.`);
  };

  const handleShare = (trackName: string) => {
    if(!user) return;
    const url = `${window.location.origin}?shared_by=${encodeURIComponent(user)}&track=${encodeURIComponent(trackName)}`;
    navigator.clipboard.writeText(url).then(() => {
        notify("Share link copied to clipboard!");
    });
  };

  // === PLAYER LOGIC ===
  const handleFileChange = (file: File): void => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioFile(file);
    const newUrl = URL.createObjectURL(file);
    setAudioUrl(newUrl);
    setIsPlaying(false);
    setIsFullScreen(false);
    if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
    }
    if (sourceRef.current) sourceRef.current.disconnect();
    sourceRef.current = null;
  };

  const setupAudioContext = useCallback(() => {
    if (!audioRef.current) return;
    if (!audioContextRef.current) {
      const context = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = context;
    }
    if (!sourceRef.current) {
       const newAnalyser = audioContextRef.current.createAnalyser();
       setAnalyser(newAnalyser);
       const source = audioContextRef.current.createMediaElementSource(audioRef.current);
       sourceRef.current = source;
       source.connect(newAnalyser);
       newAnalyser.connect(audioContextRef.current.destination);
    }
  }, []);

  const togglePlayPause = (): void => {
    if (!audioRef.current) return;
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    if (!isPlaying) {
      setupAudioContext();
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        if (!isFullScreen) setIsFullScreen(true);
      }).catch(e => console.error("Error playing audio:", e));
    } else {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setIsFullScreen(false);
    if (audioRef.current) audioRef.current.currentTime = 0;
  };
  
  const exitFullScreen = useCallback(() => setIsFullScreen(false), []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && isFullScreen) exitFullScreen();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullScreen, exitFullScreen]);

  // === RENDER LOGIC ===
  if (!user) {
    if (sharedTrackInfo) {
      return (
          <div className="min-h-screen bg-[#111111] text-gray-100 flex flex-col items-center justify-center p-4 font-sans">
              <div className="text-center bg-black/30 p-8 rounded-lg border border-gray-700/50">
                  <h1 className="text-2xl font-bold text-white">You're viewing a shared track</h1>
                  <p className="text-gray-300 mt-2">
                      <span className="font-bold text-purple-400">{sharedTrackInfo.track}</span> shared by <span className="font-bold text-purple-400">{sharedTrackInfo.user}</span>.
                  </p>
                  <button onClick={() => setSharedTrackInfo(null)} className="mt-6 bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-md transition-colors">
                      Enter ROYWAV
                  </button>
              </div>
          </div>
      );
    }
    return <div className="min-h-screen bg-[#111111]"><Auth onLogin={handleLogin} /></div>;
  }
  
  const NavLink: React.FC<{
    currentView: View,
    targetView: View,
    onClick: () => void,
    children: React.ReactNode
  }> = ({ currentView, targetView, onClick, children }) => (
    <button onClick={onClick} className={`transition-colors text-sm md:text-base ${currentView === targetView ? 'text-white font-bold' : 'text-gray-400 hover:text-white'}`}>
      {children}
    </button>
  );

  return (
    <div className="min-h-screen bg-[#111111] text-gray-100 flex flex-col items-center p-4 font-sans selection:bg-purple-500/50">
      {isFullScreen && (
        <div className="fixed inset-0 w-full h-full bg-[#111111] z-40">
            <AudioVisualizer analyserNode={analyser} isPlaying={isPlaying} settings={visualizerSettings} />
            <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 bg-black/50 backdrop-blur-md py-2 px-4 rounded-full">
                <button onClick={togglePlayPause} className="bg-purple-600 hover:bg-purple-500 text-white rounded-full p-3 transition-transform duration-300 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-400" aria-label={isPlaying ? 'Pause' : 'Play'}>
                    {isPlaying ? <PauseIcon /> : <PlayIcon />}
                </button>
                 <button onClick={exitFullScreen} className="bg-gray-600/50 hover:bg-gray-500/80 text-white rounded-full p-3 transition-transform duration-300 ease-in-out hover:scale-110 focus:outline-none focus:ring-2 focus:ring-gray-400" aria-label="Exit full screen">
                    <ExitFullScreenIcon />
                </button>
            </div>
        </div>
      )}

      {showNotification && (
          <div className="fixed top-5 right-5 bg-purple-600 text-white py-2 px-4 rounded-lg shadow-lg z-50 animate-pulse">
            {showNotification}
          </div>
      )}
      
      <div className={`w-full max-w-4xl mx-auto flex flex-col items-center space-y-8 transition-opacity duration-300 ${isFullScreen ? 'opacity-0 invisible' : 'opacity-100 visible'}`}>
        <header className="w-full flex justify-between items-center py-4">
            <div className="flex items-center gap-4 md:gap-6">
                 <button onClick={() => setView('app')} className="flex items-center gap-2 group">
                    <RoyWavIcon />
                    <span className="text-xl font-bold text-white group-hover:text-purple-400 transition-colors hidden sm:inline">ROYWAV</span>
                </button>
                <nav className="flex items-center gap-4 md:gap-6">
                    <NavLink currentView={view} targetView="library" onClick={() => setView('library')}>My Library</NavLink>
                    <NavLink currentView={view} targetView="gallery" onClick={() => setView('gallery')}>Public Gallery</NavLink>
                </nav>
            </div>
            <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400 hidden md:inline">Welcome, <span className="font-bold text-gray-200">{user}</span></span>
                <button onClick={handleLogout} title="Logout" className="text-gray-400 hover:text-white transition-colors p-2"><LogoutIcon /></button>
            </div>
        </header>
        
        {view === 'app' && (
          <div className="w-full max-w-2xl flex flex-col items-center space-y-6 pt-12">
            {!audioFile ? (
              <>
                <h1 className="text-3xl md:text-4xl font-bold text-white tracking-tight">Experience your sound.</h1>
                <p className="text-lg text-gray-400 mt-2 text-center">Upload an audio file to start the visualization.</p>
                <div className="w-full pt-4">
                  <AudioUploader onFileChange={handleFileChange} />
                </div>
              </>
            ) : (
            <>
              <div className="w-full h-64 bg-black rounded-lg overflow-hidden relative shadow-2xl shadow-purple-900/20 border border-gray-800">
                <AudioVisualizer analyserNode={analyser} isPlaying={isPlaying} settings={visualizerSettings} />
              </div>

              <div className="w-full flex flex-col items-center space-y-4">
                <p className="text-center text-gray-300 truncate w-full px-4" title={audioFile.name}>
                  Now Playing: <span className="font-bold text-white">{audioFile.name}</span>
                </p>

                <div className="flex items-center space-x-4">
                  <button onClick={togglePlayPause} className="bg-purple-600 hover:bg-purple-500 text-white rounded-full p-4 transition-all duration-300 ease-in-out transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-purple-400" aria-label={isPlaying ? 'Pause' : 'Play in full screen'}>
                    {isPlaying ? <PauseIcon /> : <PlayIcon />}
                  </button>
                </div>
                
                <button onClick={() => { setAudioFile(null); setAudioUrl(null); }} className="text-sm text-gray-400 hover:text-white transition-colors duration-200">
                  Upload another file
                </button>
              </div>

              {/* Save Controls */}
              <div className="w-full max-w-md bg-black/20 border border-gray-700/50 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                      <span className="font-medium text-gray-200">Save to Library</span>
                      <button onClick={() => setIsPublic(!isPublic)} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white" title={isPublic ? 'Visible to everyone' : 'Only visible to you'}>
                          {isPublic ? <GlobeIcon size={16}/> : <LockIcon size={16}/>}
                          <span>{isPublic ? 'Public' : 'Private'}</span>
                      </button>
                  </div>
                  <button onClick={handleSaveTrack} disabled={savedTracks.some(t => t.name === audioFile.name)} className="bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-md transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed">
                      {savedTracks.some(t => t.name === audioFile.name) ? 'Saved' : 'Save'}
                  </button>
              </div>

              <SettingsPanel settings={visualizerSettings} onSettingsChange={setVisualizerSettings} />
            </>
          )}
          </div>
        )}

        {view === 'library' && (
          <MyLibrary
            tracks={savedTracks}
            username={user}
            onShare={handleShare}
            onBack={() => setView('app')}
            onTogglePrivacy={handleToggleTrackPrivacy}
          />
        )}
        
        {view === 'gallery' && (
          <PublicGallery 
            tracks={publicTracks} 
            onBack={() => setView('app')} 
          />
        )}

        {audioUrl && <audio ref={audioRef} src={audioUrl} onEnded={handleEnded} crossOrigin="anonymous"></audio>}
      </div>
    </div>
  );
}
